frappe.listview_settings["CD Assets Movement"] = {
    get_indicator: function (doc) {
		// var colors = {
		// 	"None": "gray",
		// 	"Good": "green",
		// 	"In Maintenance": "orange",
		// 	"Broken": "red",
		// }
        
        // if (doc.status) {
        //     return [__(doc.status), colors[doc.status], "status,=," + doc.status];
        // } else {
        //     return [__(doc.type), colorsHard[doc.type], "type,=," + doc.type];
        // }
	},
};
