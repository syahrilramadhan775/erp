# Copyright (c) 2023, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class CDAssetSarpras(Document):
    pass
	# def autoname(self):
	# 	self.name = f'{self.sarpras_name} ({self.room})'
	
	# def validate(self):
	# 	self.room = self.room
